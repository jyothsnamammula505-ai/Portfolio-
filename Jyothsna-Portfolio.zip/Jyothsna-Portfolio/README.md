# Jyothsna Portfolio

A responsive personal portfolio website built with plain HTML, CSS and JavaScript.

## Files
- `index.html` — portfolio content
- `style.css` — design and responsive layout
- `script.js` — mobile navigation

## Run locally
1. Open the folder in VS Code.
2. Open `index.html` in a browser.
3. For the easiest development workflow, install the VS Code **Live Server** extension and choose **Open with Live Server**.

## Publish on GitHub Pages
1. Create a GitHub repository, for example `jyothsna-portfolio`.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/root`, then Save.
6. GitHub will provide your public portfolio URL.

## Before publishing
Replace or add any project GitHub links, project screenshots, certificate links, and a professional profile photo if you want them displayed.
